#!/bin/sh

~/cp2k_danny_20091116/exe/Linux-x86-64-intel/cp2k.sdbg silica_water_NVT_new.inp > silica_water_NVT_new.out
